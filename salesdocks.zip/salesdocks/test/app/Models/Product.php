<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Product extends Model
{
    protected $table = 'products';

    public function getProduct($condition,$or_condition)
    {

        $data = DB::table($this->table)
        ->where($condition)
        ->where(function ($query) use ($or_condition) {
            if(count($or_condition) > 0){

                foreach($or_condition as $key=>$or){

                    if($key == 0){

                        $query->where($or[0],$or[1],$or[2]);

                    }
                    else{

                        $query->orWhere($or[0],$or[1],$or[2]);

                    }


                }

            }
        })
        ->get();

        return $data;
    }

}
