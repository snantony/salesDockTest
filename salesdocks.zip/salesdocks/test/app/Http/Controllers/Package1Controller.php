<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Product;

class Package1Controller extends Controller
{
    private $product_model;
    private $filters = [];
    private $condition = [];
    private $or_condition = [];

    function __construct()
    {
        $this->product_model = new Product();
    }

    public function index()
    {

        $this->uploadGreaterThan100();

        $this->downloadGreaterThan100();

        $this->uploadSpeedLessThan100AndFiber();

        // echo '<pre>';
        // print_r($this->or_condition);
        // echo '</pre>';
        // exit;

        $datas = $this->product_model->getProduct($this->condition,$this->or_condition);

        return view('productsList', ['datas' => $datas,'filters'=>$this->filters]);

    }

//to group common columns
    private function simplify_condition($array){

        if(count($this->condition) > 0){

            $dummy = [];
            $add = 0;

            foreach($this->condition as $key=>$check){

                if($check[0] == $array[0]){

                    $this->or_condition[] = $check;
                    $this->or_condition[] = $array;

                    unset($this->condition[$key]);

                    $add += 1;

                }
                else{

                    $dummy[] = $check;

                }

            }

            if($add == 0){

                $dummy[] = $array;

            }

            $this->condition = $dummy;

            return;

        }
        else{

            $this->condition[] = $array;
            return;

        }

    }
//to group common columns(end)






    private function uploadGreaterThan100()
    {
        $this->simplify_condition(['upload_speed','>',100]);
        $this->filters[] = 'Upload Speed Greater Than 100';

        return;
    }

    private function downloadGreaterThan100()
    {
        $this->simplify_condition(['download_speed','>',100]);
        $this->filters[] = 'Download Speed Greater Than 100';

        return;
    }

    private function uploadSpeedLessThan100AndFiber()
    {
        $this->simplify_condition(['upload_speed','<',100]);
        $this->simplify_condition(['technology','=','0']);
        $this->filters[] = 'Upload Speed less than 100';
        $this->filters[] = 'Is Fiber';

        return;
    }

}
