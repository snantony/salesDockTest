<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateProducts extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('products', function (Blueprint $table) {
            $table->id('product_id')->autoIncrement();
            $table->string('product_name',100);
            $table->smallInteger('upload_speed');
            $table->smallInteger('download_speed');
            $table->enum('technology',['0','1'])->comment('0->fiber,1->dialup');//0->fiber,1->dialup
            $table->enum('static_ip',['0','1'])->comment('0->no,1->yes');//0->no,1->yes
            $table->dateTime('created_at', 0)->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('products');
    }
}
